# importing the Yagmail library
import yagmail

try:
    # initializing the server connection
    yag = yagmail.SMTP(
        user="switchmazebot2000@gmail.com", oauth2_file="~/oauth2_creds.json"
    )
    # sending the email
    yag.send(
        to="m.m.karnani@vu.nl",
        subject="Testing Yagmail",
        contents="""
        Hi, this is Vini, let me know if you have received this message.
        
        I will send you the code, but there is some faffing to be done – I will see if I can explain it clearly in my email.

        """,
    )
    print("Email sent successfully")
except:
    print("Error, email was not sent")
